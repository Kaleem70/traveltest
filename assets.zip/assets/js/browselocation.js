(function ($) {
    "use strict";
    
    // Top 5 famous countries to show initially
    const topDestinations = [
        { name: "United States", state: "New York" },
        { name: "France", state: "Paris" },
        { name: "Japan", state: "Tokyo" },
        { name: "Italy", state: "Rome" },
        { name: "Spain", state: "Barcelona" }
    ];

    // Full list of countries and states with airports (sample data - you should expand this)
    const allDestinations = [
        { name: "United States", state: "New York" },
        { name: "United States", state: "Los Angeles" },
        { name: "United States", state: "Chicago" },
        { name: "France", state: "Paris" },
        { name: "France", state: "Nice" },
        { name: "Japan", state: "Tokyo" },
        { name: "Japan", state: "Osaka" },
        { name: "Italy", state: "Rome" },
        { name: "Italy", state: "Milan" },
        { name: "Spain", state: "Barcelona" },
        { name: "Spain", state: "Madrid" },
        { name: "Canada", state: "Toronto" },
        { name: "India", state: "Delhi" },
        { name: "India", state: "Mumbai" },
        { name: "Thailand", state: "Bangkok" },
        { name: "United Kingdom", state: "London" },
        { name: "Singapore", state: "Singapore" },
        { name: "United Arab Emirates", state: "Dubai" },
        { name: "Australia", state: "Sydney" },
        // Add more countries and states as needed
    ];

    document.querySelectorAll(".flightInput").forEach(input => {
        const container = input.closest(".autocomplete-container");
        const suggestionsBox = container.querySelector(".suggestions");

        const showSuggestions = (showTopDestinations = false) => {
            const query = input.value.toLowerCase().trim();
            suggestionsBox.innerHTML = "";

            let filtered = [];
            
            if (showTopDestinations && query === "") {
                // Show top 5 destinations when input is empty
                filtered = topDestinations;
            } else {
                // Filter based on both country and state
                filtered = allDestinations.filter(dest =>
                    dest.name.toLowerCase().includes(query) || 
                    dest.state.toLowerCase().includes(query)
                );
            }

            if (filtered.length === 0) {
                const noResults = document.createElement("div");
                noResults.className = "suggestion-item no-results";
                noResults.textContent = "No destinations found";
                suggestionsBox.appendChild(noResults);
                return;
            }

            filtered.forEach(dest => {
                const item = document.createElement("div");
                item.className = "suggestion-item";
                item.innerHTML = `
                    <div class="place-name"><i class="bi bi-geo-alt"></i> ${dest.name}, ${dest.state}</div>
                `;
                item.onclick = () => {
                    input.value = `${dest.name}, ${dest.state}`;
                    suggestionsBox.innerHTML = "";
                };
                suggestionsBox.appendChild(item);
            });
        };

        input.addEventListener("focus", () => showSuggestions(true));
        input.addEventListener("input", () => showSuggestions(false));
    });

    document.addEventListener("click", e => {
        document.querySelectorAll(".suggestions").forEach(box => {
            if (!e.target.closest(".autocomplete-container")) {
                box.innerHTML = "";
            }
        });
    });
    
})(this.jQuery);