<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get all form data
$enquiryType = $_POST['enquiry_type'] ?? '';
$fullName = $_POST['full_name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$message = $_POST['message'] ?? '';

// Validate required fields
if (empty($fullName) || empty($email) || empty($phone) || empty($enquiryType)) {
    echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
    exit;
}

// Get enquiry-specific data
if ($enquiryType === 'flight') {
    $tripType = $_POST['trip_type'] ?? '';
    $leavingFrom = $_POST['leaving_from'] ?? '';
    $goingTo = $_POST['going_to'] ?? '';
    $travelDate = $_POST['travel_date'] ?? '';
    $adults = $_POST['adults'] ?? 1;
    $children = $_POST['children'] ?? 0;
    $passengersSummary = $_POST['passengers_summary'] ?? '';
    
    if (empty($leavingFrom) || empty($goingTo) || empty($travelDate)) {
        echo json_encode(['success' => false, 'message' => 'Please fill all flight details']);
        exit;
    }
} 
elseif ($enquiryType === 'hotel') {
    $location = $_POST['hotel_location'] ?? '';
    $checkInDate = $_POST['check_in_date'] ?? '';
    $checkOutDate = $_POST['check_out_date'] ?? '';
    $rooms = $_POST['rooms'] ?? 1;
    $adults = $_POST['hotel_adults'] ?? 1;
    $children = $_POST['hotel_children'] ?? 0;
    $budget = $_POST['budget'] ?? '';
    $roomsGuestsSummary = $_POST['rooms_guests_summary'] ?? '';
    
    if (empty($location) || empty($checkInDate) || empty($checkOutDate)) {
        echo json_encode(['success' => false, 'message' => 'Please fill all hotel details']);
        exit;
    }
}

// Load Composer's autoloader
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.yourprovider.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'your@email.com';
    $mail->Password   = 'yourpassword';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    
    // Recipients
    $mail->setFrom('noreply@yourdomain.com', 'Your Travel Agency');
    $mail->addAddress($email, $fullName);
    $mail->addBCC('owner@yourdomain.com', 'Website Owner');
    
    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Your ' . ucfirst($enquiryType) . ' Enquiry Confirmation';
    
    // Build email content based on enquiry type
    $userEmailContent = "
        <h2>Thank you for your enquiry, $fullName!</h2>
        <p>We've received your request and will get back to you shortly with the best options.</p>
        
        <h3>Your Contact Information:</h3>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Phone:</strong> $phone</p>
    ";
    
    if ($enquiryType === 'flight') {
        $userEmailContent .= "
            <h3>Your Flight Details:</h3>
            <p><strong>Trip Type:</strong> " . ($tripType === 'return' ? 'Round Trip' : 'One Way') . "</p>
            <p><strong>From:</strong> $leavingFrom</p>
            <p><strong>To:</strong> $goingTo</p>
            <p><strong>Travel Date:</strong> $travelDate</p>
            <p><strong>Passengers:</strong> $passengersSummary</p>
        ";
    } 
    else {
        $userEmailContent .= "
            <h3>Your Hotel Requirements:</h3>
            <p><strong>Location:</strong> $location</p>
            <p><strong>Check-in Date:</strong> $checkInDate</p>
            <p><strong>Check-out Date:</strong> $checkOutDate</p>
            <p><strong>Guests:</strong> $roomsGuestsSummary</p>
            <p><strong>Budget:</strong> " . (empty($budget) ? 'Not specified' : '$' . $budget) . "</p>
        ";
    }
    
    $userEmailContent .= "
        <h3>Additional Notes:</h3>
        <p>" . (empty($message) ? 'None' : nl2br($message)) . "</p>
        
        <p>We'll contact you within 24 hours to discuss your requirements.</p>
        <p>Best regards,<br>Your Travel Team</p>
    ";
    
    $mail->Body = $userEmailContent;
    $mail->AltBody = strip_tags($userEmailContent);
    
    $mail->send();
    
    // Send separate email to owner
    $ownerMail = new PHPMailer(true);
    $ownerMail->isSMTP();
    $ownerMail->Host       = 'smtp.yourprovider.com';
    $ownerMail->SMTPAuth   = true;
    $ownerMail->Username   = 'your@email.com';
    $ownerMail->Password   = 'yourpassword';
    $ownerMail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $ownerMail->Port       = 587;
    
    $ownerMail->setFrom('noreply@yourdomain.com', 'Website Enquiry');
    $ownerMail->addAddress('owner@yourdomain.com', 'Website Owner');
    
    $ownerMail->isHTML(true);
    $ownerMail->Subject = 'New ' . ucfirst($enquiryType) . ' Enquiry from ' . $fullName;
    
    $ownerEmailContent = "
        <h2>New " . ucfirst($enquiryType) . " Enquiry Received</h2>
        <p><strong>From:</strong> $fullName</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Phone:</strong> $phone</p>
    ";
    
    if ($enquiryType === 'flight') {
        $ownerEmailContent .= "
            <h3>Flight Details:</h3>
            <p><strong>Trip Type:</strong> " . ($tripType === 'return' ? 'Round Trip' : 'One Way') . "</p>
            <p><strong>From:</strong> $leavingFrom</p>
            <p><strong>To:</strong> $goingTo</p>
            <p><strong>Travel Date:</strong> $travelDate</p>
            <p><strong>Passengers:</strong> $passengersSummary</p>
        ";
    } 
    else {
        $ownerEmailContent .= "
            <h3>Hotel Requirements:</h3>
            <p><strong>Location:</strong> $location</p>
            <p><strong>Check-in Date:</strong> $checkInDate</p>
            <p><strong>Check-out Date:</strong> $checkOutDate</p>
            <p><strong>Guests:</strong> $roomsGuestsSummary</p>
            <p><strong>Budget:</strong> " . (empty($budget) ? 'Not specified' : '$' . $budget) . "</p>
        ";
    }
    
    $ownerEmailContent .= "
        <h3>Additional Notes:</h3>
        <p>" . (empty($message) ? 'None provided' : nl2br($message)) . "</p>
        
        <p>Please contact the customer as soon as possible.</p>
    ";
    
    $ownerMail->Body = $ownerEmailContent;
    $ownerMail->AltBody = strip_tags($ownerEmailContent);
    
    $ownerMail->send();
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"]);
}