<?php
header('Content-Type: application/json');

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get all form data
$location = $_POST['hotel_location'] ?? '';
$checkInDate = $_POST['check_in_date'] ?? '';
$roomsGuests = $_POST['rooms_guests'] ?? '';
$budget = $_POST['budget'] ?? '';
$fullName = $_POST['full_name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$message = $_POST['message'] ?? '';

// Validate required fields
if (empty($fullName) || empty($email) || empty($phone)) {
    echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
    exit;
}

// Load Composer's autoloader (if using PHPMailer via Composer)
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(true);

try {
    // Server settings (same as your flight enquiry)
    $mail->isSMTP();
    $mail->Host       = 'smtp.yourprovider.com'; // Your SMTP server
    $mail->SMTPAuth   = true;
    $mail->Username   = 'your@email.com'; // SMTP username
    $mail->Password   = 'yourpassword'; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    
    // Recipients
    $mail->setFrom('noreply@yourdomain.com', 'Your Travel Agency');
    $mail->addAddress($email, $fullName); // Send to user
    $mail->addBCC('owner@yourdomain.com', 'Website Owner'); // BCC to owner
    
    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Your Hotel Enquiry Confirmation';
    
    // Email content for user
    $userEmailContent = "
        <h2>Thank you for your hotel enquiry, $fullName!</h2>
        <p>We've received your request and will get back to you shortly with the best options.</p>
        
        <h3>Your Hotel Requirements:</h3>
        <p><strong>Location:</strong> $location</p>
        <p><strong>Check-in Date:</strong> $checkInDate</p>
        <p><strong>Room & Guests:</strong> $roomsGuests</p>
        <p><strong>Budget:</strong> " . (empty($budget) ? 'Not specified' : '$' . $budget) . "</p>
        
        <h3>Your Contact Information:</h3>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Phone:</strong> $phone</p>
        <p><strong>Additional Requirements:</strong> " . (empty($message) ? 'None' : nl2br($message)) . "</p>
        
        <p>We'll contact you within 24 hours to discuss your accommodation needs.</p>
        <p>Best regards,<br>Your Travel Team</p>
    ";
    
    $mail->Body = $userEmailContent;
    $mail->AltBody = strip_tags($userEmailContent);
    
    $mail->send();
    
    // Send a separate email to the owner with the same details
    $ownerMail = new PHPMailer(true);
    $ownerMail->isSMTP();
    $ownerMail->Host       = 'smtp.yourprovider.com';
    $ownerMail->SMTPAuth   = true;
    $ownerMail->Username   = 'your@email.com';
    $ownerMail->Password   = 'yourpassword';
    $ownerMail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $ownerMail->Port       = 587;
    
    $ownerMail->setFrom('noreply@yourdomain.com', 'Website Enquiry');
    $ownerMail->addAddress('owner@yourdomain.com', 'Website Owner');
    
    $ownerMail->isHTML(true);
    $ownerMail->Subject = 'New Hotel Enquiry from ' . $fullName;
    
    $ownerEmailContent = "
        <h2>New Hotel Enquiry Received</h2>
        <p><strong>From:</strong> $fullName</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Phone:</strong> $phone</p>
        
        <h3>Hotel Requirements:</h3>
        <p><strong>Location:</strong> $location</p>
        <p><strong>Check-in Date:</strong> $checkInDate</p>
        <p><strong>Room & Guests:</strong> $roomsGuests</p>
        <p><strong>Budget:</strong> " . (empty($budget) ? 'Not specified' : '$' . $budget) . "</p>
        
        <h3>Additional Requirements:</h3>
        <p>" . (empty($message) ? 'None provided' : nl2br($message)) . "</p>
        
        <p>Please contact the customer as soon as possible.</p>
    ";
    
    $ownerMail->Body = $ownerEmailContent;
    $ownerMail->AltBody = strip_tags($ownerEmailContent);
    
    $ownerMail->send();
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"]);
}